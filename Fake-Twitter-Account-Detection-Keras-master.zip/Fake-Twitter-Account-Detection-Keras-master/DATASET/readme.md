# This folder contains dataset for fake and legit users in csv format.
