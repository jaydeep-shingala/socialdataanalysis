# Fake-Twitter-Account-Detection-Keras
Using Deep Neural Network to create a predictive model for Fake Account Detection.

## Accuracy over epochs
![Accuracy Graph](res/acc_graph.png)

*Validation Accuracy : ~98%*

## Confusion Matrix of Prediction on Validation dataset
![Confusion Matrix](res/confusion.png)
